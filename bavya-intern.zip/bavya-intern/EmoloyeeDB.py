import sqlite3

con = sqlite3.connect("employee.db")
print("Database opened successfully")

con.execute(
    "create table Employees (id INTEGER PRIMARY KEY AUTOINCREMENT,a_name TEXT NOT NULL, q_email TEXT UNIQUE NOT NULL, am_address TEXT NOT NULL,tc_address TEXT NOT NULL,st_address TEXT NOT NULL,re_address TEXT NOT NULL)")

print("Table created successfully")

con.close()